<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>PRACTICA HLC04 - SERGIO RUIZ</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

    <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/bootstrap/css/boostrap.min.css"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Esto se hace para que se tenga ese tipo de letra en el documento
      No se puede aplicar en el boostrap ya que no surge efecto
-->
  <style>
    body
    {
      font-family: 'Poppins', sans-serif;
    }
  </style>

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top sticky-top fixed-top">
    <div class="container">
      <a class="navbar-brand" href="inicio.php">INICIO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="boostrap.php">BOOSTRAP
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="jquery.php">JQUERY</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_local.php">JSON LOCAL</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_externo.php">JSON EXTERNO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="angularJS.php">ANGULAR JS</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
  <div class="row">


    <!-- Script para los botones-->
    <script>
    $(document).ready(function(){
      $("#boton1").click(function(){
        $("#p1").css("color", "blue").slideUp(2000).slideDown(2000);
      });
    });

    $(document).ready(function(){
      $("#boton2").click(function(){
        $("#parrafo").hide("slow", function(){
          alert("Se ocultó el contenido satisfactoriamente");
        });
      });
    });

    $(document).ready(function(){
      $("#boton3").click(function(){
        $("#parrafo").show("slow", function(){
          alert("Se mostró el contenido satisfactoriamente");
        });
      });
    });
    </script>




    <section id="demo" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ul class="carousel-indicators">
        <li data-target="#demo" data-slide-to="0" class="active"></li>
        <li data-target="#demo" data-slide-to="1"></li>
        <li data-target="#demo" data-slide-to="2"></li>
        <li data-target="#demo" data-slide-to="3"></li>
      </ul>
      
      <!-- The slideshow -->
      <!-- Esto se hace para que sea completamente responsive-->
      <style>
      /* Make the image fully responsive */
      .carousel-inner img {
          width: 100%;
          height: 100%;
      }
      </style>

      <div class="carousel-inner">  
        <div class="carousel-item">
          <img src="img/futbol_json.png" alt="New York" width="1100" height="500">
        </div>
        <div class="carousel-item active">
          <img src="img/jquery_logo.jpg" alt="Los Angeles" width="1100" height="500">
        </div>
        <div class="carousel-item">
          <img src="img/AngularJS_logo.svg.png" alt="Chicago" width="1100" height="500">
        </div>
        <div class="carousel-item">
          <img src="img/json-logo.png" alt="New York" width="1100" height="500">
        </div>
      </div>
      
      <!-- Left and right controls -->
      <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </a>
      <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
      </a>
    </section>

      <article class="container p-3 my-3 bg-primary text-white">
        <div class="spinner-grow text-light"></div>
          <section id ="parrafo">
            <h2 class = "text-center" id="p1">CONOCE UN POCO MAS JQUERY</h2></br>
            <p class="lead"> JQuery es una librería de JavaScript (JavaScript es un lenguaje de programación muy usado en desarrollo web). Esta librería de código abierto, simplifica la tarea de programar en JavaScript y permite agregar interactividad a un sitio web sin tener conocimientos del lenguaje.</p>
            <p class = "lead">Basados en esta librería, existe una infinita cantidad de plugins (gratis y pagos) creados por desarrolladores de todo el mundo. Estos plugins resuelven situaciones concretas dentro del maquetado de un sitio, por ejemplo: un menú responsive, una galería de fotos, un carrousel de imágenes, un slide, un header que cambia de tamaño, el deslizamiento del scroll al hacer clic en un botón (anclas HTML), la transición entre páginas y miles de efectos más.</p>
            <p class ="lead">Cada plugin tiene un sitio web desde donde se pueden descargar sus archivos, con demos, instrucciones para su implementación, opciones de configuración e información de las licencias. En la web hay cientos de blogs que recopilan y analizan los plugins según sus funcionalidades, reuniendo en un sólo post los links a varios plugins de función similar, lo que facilita mucho la búsqueda.</p>
          </section>
      </article>

      <article class="container p-3 my-3 bg-primary text-white">
        <div class="spinner-grow text-light"></div><br><br>
        <button class="button" id="boton1">Boton sorpresa</button>
        <button class="button" id="boton2">OCULTAR</button>
        <button class="button" id="boton3">MOSTRAR</button>
     </article>




    </div>
  </div>

  <!-- Bootstrap core JavaScript -->


</body>

</html>
