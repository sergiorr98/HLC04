<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>PRACTICA HLC04 - SERGIO RUIZ</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

<!-- Esto se hace para que se tenga ese tipo de letra en el documento
      No se puede aplicar en el boostrap ya que no surge efecto
-->
  <style>
    body
    {
      font-family: 'Poppins', sans-serif;
    }
  </style>

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top sticky-top">
    <div class="container">
      <a class="navbar-brand" href="inicio.php">INICIO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="boostrap.php">BOOSTRAP
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="jquery.php">JQUERY</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_local.php">JSON LOCAL</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_externo.php">JSON EXTERNO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="angularJS.php">ANGULAR JS</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <br><div class="container">
  <div class="card">
    <div class="card-body">
      <h1 class ="text-center">¡BIENVENIDO!</h1>
      <h2>Adentrate en esta página para enriquecerte de la información más actual y relevante acerca de las nuevas tecnologias web.</h2>
      <h3>A continuación se muestran tarjetas sobre los artículos que se tratan en está pagina. ¡No te cortes, echales un vistazo!</h3>
    </div>
  </div>
</div>

  <br>  
  <div class="container" width="200px" height="300px">
      <div class="card">
        <img class="card-img-top" src="img/boostrap_logo.png" alt="Card image" style="width:100%">
        <div class="card-body">
        <h4 class="card-title">Boostrap</h4>
        <p class="card-text">Informate sobre que es el FRONT-END y el BACK-END.</p>
        <a href="boostrap.php" class="btn btn-primary">Entrar</a>
        </div>
      </div>
  </div>
  <br>

  <div class="container" width="200px" height="300px">
    <div class="card">
      <img class="card-img-top" src="img/futbol_json.png" alt="Card image" style="width:100%">
      <div class="card-body">
      <h4 class="card-title">JSON LOCAL</h4>
      <p class="card-text">Vea nuestra base de datos de Fútbol gracias a JSON.</p>
      <a href="json_local.php" class="btn btn-primary">Entrar</a>
      </div>
    </div>
  </div>
  <br>

  <div class="container" width="200px" height="300px">
    <div class="card">
      <img class="card-img-top" src="img/json-logo.png" alt="Card image" style="width:100%">
      <div class="card-body">
      <h4 class="card-title">JSON EXTERNO</h4>
      <p class="card-text">Vea en forma de tabla más información acerca del FRONT-END y el BACK-END.</p>
      <a href="json_externo.php" class="btn btn-primary">Entrar</a>
      </div>
    </div>
  </div>
  <br>

  <div class="container" width="200px" height="300px">
    <div class="card e">
      <img class="card-img-top" src="img/AngularJS_logo.svg.png" alt="Card image" style="width:100%">
      <div class="card-body">
      <h4 class="card-title">ANGULAR JS</h4>
      <p class="card-text">Informate sobre Angular JS, y aprende mas de una gran y potente herramienta.</p>
      <a href="angularJS.php" class="btn btn-primary">Entrar</a>
    </div>
    </div>
  </div>
  <br>

  <div class="container" width="200px" height="300px">
    <div class="card">
      <img class="card-img-top" src="img/jquery_logo.jpg" alt="Card image" style="width:100%">
      <div class="card-body">
      <h4 class="card-title">JQUERY</h4>
      <p class="card-text">Informate acerca de JQUERY y de las funcionalidades que ofrece</p>
      <a href="jquery.php" class="btn btn-primary">Entrar</a>
    </div>
    </div>
  </div>
  <br>



  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

</body>

</html>
