<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="vendor/js/botonesJson.js"></script>

  <title>PRACTICA HLC04 - SERGIO RUIZ</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

<!-- Esto se hace para que se tenga ese tipo de letra en el documento
      No se puede aplicar en el boostrap ya que no surge efecto
-->
  <style>
    body
    {
      font-family: 'Poppins', sans-serif;
    }
  </style>

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top sticky-top fixed-top">
    <div class="container">
      <a class="navbar-brand" href="inicio.php">INICIO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="boostrap.php">BOOSTRAP</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="jquery.php">JQUERY</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_local.php">JSON LOCAL</a>
            <span class="sr-only">(current)</span>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_externo.php">JSON EXTERNO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="angularJS.php">ANGULAR JS</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    <!-- Page Content -->
  <br><div class="container p-3 my-3 bg-primary text-white">
      <div class="card-body">
        <h1 class ="text-center">¡BIENVENIDO!</h1>
        <h2>A continuación se muestra la información sacada de un base de datos local de ejemplo con relacion 1:N. </h2>
        <h3>¡Juega con el filtro para mostrar aquel contenido que desees!</h3>
      </div>
  </div>

  <!-- Page Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h1 class="mt-5">ARBITROS  -  PARTIDOS </h1>

  

        <!-- Contenido -->
  <div class="dropdown">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
     Elige un arbitro
    </button>
    <div class="dropdown-menu">
      <button class="dropdown-item" id="boton1"> 111A - SANCHEZ</button>
      <button class="dropdown-item" id="boton2"> 222A - GONZALEZ</button>
      <button class="dropdown-item" id="boton3"> 333C - JIMENEZ</button>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" id="boton4">Mostrar todo</button>
    </div>
  </div>

        <section>
            
        </br></br><h2 class="mt-5" id="parrafoArbitro1">ARBITRO SANCHEZ</h2>

          <table class="table" id="tablaArbitro1">
          <thead>
          <th>CODIGO</th>
          <th>ESTADIO</th>
          <th>CAPACIDAD</th>
          <th>ARBITRO</th>
          </thead>
          <tbody></tbody>
          </table>

          <script type="text/javascript">

          $(document).ready(function(){
          var url="generarJSON.php?valor=111A";
          $("#tablaArbitro1 tbody").html("");
          $.getJSON(url,function(clientes){
          $.each(clientes, function(i,cliente){
          var newRow =
          "<tr>"
          +"<td>"+cliente.CODIGO+"</td>"
          +"<td>"+cliente.ESTADIO+"</td>"
          +"<td>"+cliente.CAPACIDAD+"</td>"
          +"<td>"+cliente.CODIGO_ARBITRO+"</td>"
          +"</tr>";
          $(newRow).appendTo("#tablaArbitro1 tbody");
          });
          });
          });

          </script>

 
        </section>

          
        <!-- Contenido -->
        <section>

        </br></br><h2 class="mt-5"  id="parrafoArbitro2">ARBITRO GONZALEZ</h2>

          <table class="table" id="tablaArbitro2">
          <thead>
          <th>CODIGO</th>
          <th>ESTADIO</th>
          <th>CAPACIDAD</th>
          <th>ARBITRO</th>
          </thead>
          <tbody></tbody>
          </table>

          <script type="text/javascript">

          $(document).ready(function(){
          var url="generarJSON.php?valor=222A";
          $("#tablaArbitro2 tbody").html("");
          $.getJSON(url,function(cliente){
          $.each(cliente, function(i,cliente){
          var newRow =
          "<tr>"
          +"<td>"+cliente.CODIGO+"</td>"
          +"<td>"+cliente.ESTADIO+"</td>"
          +"<td>"+cliente.CAPACIDAD+"</td>"
          +"<td>"+cliente.CODIGO_ARBITRO+"</td>"
          +"</tr>";
          $(newRow).appendTo("#tablaArbitro2  tbody");
          });
          });
          });

          </script>

        </section>


        <!-- Contenido -->
        <section>

        </br></br><h2 class="mt-5"  id="parrafoArbitro3">ARBITRO JIMENEZ</h2>

          <table class="table" id="tablaArbitro3">
          <thead>
          <th>CODIGO</th>
          <th>ESTADIO</th>
          <th>CAPACIDAD</th>
          <th>ARBITRO</th>
          </thead>
          <tbody></tbody>
          </table>

          <script type="text/javascript">

          $(document).ready(function(){
          var url="generarJSON.php?valor=333C";
          $("#tablaArbitro3 tbody").html("");
          $.getJSON(url,function(cliente){
          $.each(cliente, function(i,cliente){
          var newRow =
          "<tr>"
          +"<td>"+cliente.CODIGO+"</td>"
          +"<td>"+cliente.ESTADIO+"</td>"
          +"<td>"+cliente.CAPACIDAD+"</td>"
          +"<td>"+cliente.CODIGO_ARBITRO+"</td>"
          +"</tr>";
          $(newRow).appendTo("#tablaArbitro3 tbody");
          });
          });
          });

          </script>

        </section>
        



      </div>
    </div>
  </div>


    <!-- Footer -->
    <footer class="py-5 bg-dark">
        <div class="footer">
        <p class="m-0 text-center text-white">Sergio Ruiz Romero 2ºDAM 2020</p>
        </div>
    </footer>
</body>

</html>
