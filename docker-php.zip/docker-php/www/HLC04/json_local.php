<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

  <title>PRACTICA HLC04 - SERGIO RUIZ</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

<!-- Esto se hace para que se tenga ese tipo de letra en el documento
      No se puede aplicar en el boostrap ya que no surge efecto
-->
  <style>
    body
    {
      font-family: 'Poppins', sans-serif;
    }
  </style>

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top sticky-top fixed-top">
    <div class="container">
      <a class="navbar-brand" href="inicio.php">INICIO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="boostrap.php">BOOSTRAP</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="jquery.php">JQUERY</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_local.php">JSON LOCAL</a>
            <span class="sr-only">(current)</span>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_externo.php">JSON EXTERNO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="angularJS.php">ANGULAR JS</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h1 class="mt-5">ARBITROS  -  PARTIDOS </h1>

                <!-- Contenido -->
        <!-- Contenido -->
        <section>
            
        </br></br><h2 class="mt-5">ARBITRO 1</h2>

          <table class="table" id="tablajson">
          <thead>
          <th>CODIGO</th>
          <th>ESTADIO</th>
          <th>CAPACIDAD</th>
          <th>ARBITRO</th>
          </thead>
          <tbody></tbody>
          </table>

          <script type="text/javascript">

          $(document).ready(function(){
          var url="generarJSON.php?valor=111A";
          $("#tablajson tbody").html("");
          $.getJSON(url,function(clientes){
          $.each(clientes, function(i,cliente){
          var newRow =
          "<tr>"
          +"<td>"+cliente.CODIGO+"</td>"
          +"<td>"+cliente.ESTADIO+"</td>"
          +"<td>"+cliente.CAPACIDAD+"</td>"
          +"<td>"+cliente.CODIGO_ARBITRO+"</td>"
          +"</tr>";
          $(newRow).appendTo("#tablajson tbody");
          });
          });
          });

          </script>

 
        </section>

          
        <!-- Contenido -->
        <section>

        </br></br><h2 class="mt-5">ARBITRO 2</h2>

          <table class="table" id="t1">
          <thead>
          <th>CODIGO</th>
          <th>ESTADIO</th>
          <th>CAPACIDAD</th>
          <th>ARBITRO</th>
          </thead>
          <tbody></tbody>
          </table>

          <script type="text/javascript">

          $(document).ready(function(){
          var url="generarJSON.php?valor=222A";
          $("#t1 tbody").html("");
          $.getJSON(url,function(cliente){
          $.each(cliente, function(i,cliente){
          var newRow =
          "<tr>"
          +"<td>"+cliente.CODIGO+"</td>"
          +"<td>"+cliente.ESTADIO+"</td>"
          +"<td>"+cliente.CAPACIDAD+"</td>"
          +"<td>"+cliente.CODIGO_ARBITRO+"</td>"
          +"</tr>";
          $(newRow).appendTo("#t1  tbody");
          });
          });
          });

          </script>

        </section>


        <!-- Contenido -->
        <section>

        </br></br><h2 class="mt-5">ARBITRO 3</h2>

          <table class="table" id="t">
          <thead>
          <th>CODIGO</th>
          <th>ESTADIO</th>
          <th>CAPACIDAD</th>
          <th>ARBITRO</th>
          </thead>
          <tbody></tbody>
          </table>

          <script type="text/javascript">

          $(document).ready(function(){
          var url="generarJSON.php?valor=333C";
          $("#t tbody").html("");
          $.getJSON(url,function(cliente){
          $.each(cliente, function(i,cliente){
          var newRow =
          "<tr>"
          +"<td>"+cliente.CODIGO+"</td>"
          +"<td>"+cliente.ESTADIO+"</td>"
          +"<td>"+cliente.CAPACIDAD+"</td>"
          +"<td>"+cliente.CODIGO_ARBITRO+"</td>"
          +"</tr>";
          $(newRow).appendTo("#t tbody");
          });
          });
          });

          </script>

        </section>
        



      </div>
    </div>
  </div>



</body>

</html>
