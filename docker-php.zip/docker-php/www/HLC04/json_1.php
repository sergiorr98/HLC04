<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

  <title>PRACTICA HLC04 - SERGIO RUIZ</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="#">INICIO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">BOOSTRAP
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">JQUERY</a>
            <span class="sr-only">(current)</span>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_1">JSON LOCAL</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">JSON EXTERNO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">ANGULAR JS</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h1 class="mt-5">ARBITROS  -  PARTIDOS </h1>

                <!-- Contenido -->
        <!-- Contenido -->
        <section>
            

          <table class="table" id="tablajson">
          <thead>
          <th>CODIGO</th>
          <th>ESTADIO</th>
          <th>CAPACIDAD</th>
          <th>ARBITRO</th>
          </thead>
          <tbody></tbody>
          </table>

          <script type="text/javascript">

          $(document).ready(function(){
          var url="generarJSON.php?valor=222A";
          $("#tablajson tbody").html("");
          $.getJSON(url,function(clientes){
          $.each(clientes, function(i,cliente){
          var newRow =
          "<tr>"
          +"<td>"+cliente.CODIGO+"</td>"
          +"<td>"+cliente.ESTADIO+"</td>"
          +"<td>"+cliente.CAPACIDAD+"</td>"
          +"<td>"+cliente.CODIGO_ARBITRO+"</td>"
          +"</tr>";
          $(newRow).appendTo("#tablajson tbody");
          });
          });
          });

          </script>

 
        </section>


        <!-- Contenido -->
        <section>
          <table class="table" id="tablajson">
          <thead>
          <th>CODIGO</th>
          <th>ESTADIO</th>
          <th>CAPACIDAD</th>
          <th>ARBITRO</th>
          </thead>
          <tbody></tbody>
          </table>

          <script type="text/javascript">

          $(document).ready(function(){
          var url="generarJSON.php?valor=222A";
          $("#tablajson tbody").html("");
          $.getJSON(url,function(clientes1){
          $.each(clientes, function(i,cliente1){
          var newRow =
          "<tr>"
          +"<td>"+cliente1.CODIGO+"</td>"
          +"<td>"+cliente1.ESTADIO+"</td>"
          +"<td>"+cliente1.CAPACIDAD+"</td>"
          +"<td>"+cliente1.CODIGO_ARBITRO+"</td>"
          +"</tr>";
          $(newRow).appendTo("#tablajson tbody");
          });
          });
          });

          </script>

 
        </section>



      </div>
    </div>
  </div>



</body>

</html>
