<!DOCTYPE html>
<html lang="en" ng-app="appFrameworks"> 

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.9/angular.min.js"></script>
  <script src="vendor/AngularJS/angular-local-storage.min.js"></script>
  <script src="vendor/AngularJS/jsonexterno.js"></script>

  <title>PRACTICA HLC04 - SERGIO RUIZ</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

<!-- Esto se hace para que se tenga ese tipo de letra en el documento
      No se puede aplicar en el boostrap ya que no surge efecto
-->
  <style>
    body
    {
      font-family: 'Poppins', sans-serif;
    }
  </style>

</head>

<body ng-controller="primerControlador">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top sticky-top fixed-top">
    <div class="container">
      <a class="navbar-brand" href="inicio.php">INICIO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="boostrap.php">BOOSTRAP</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="jquery.php">JQUERY</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_local.php">JSON LOCAL</a>
            <span class="sr-only">(current)</span>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_externo.php">JSON EXTERNO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="angularJS.php">ANGULAR JS</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    <!-- Page Content -->
  <br><div class="container p-3 my-3 bg-primary text-white">
      <div class="card-body">
        <h1 class ="text-center">¡BIENVENIDO!</h1>
        <h2>A continuación se muestran la información sacada de un json externo transformado a tabla.</h2>
        <h3>La tabla muestra los principales componentes de la relacion FRONT-END y BACK-END.</h3>
        <div class="alert alert-info">
            <strong>¡Info!</strong> Si deseas saber más acerca de  <a href="http://localhost/HLC04/boostrap.php" class="alert-link"> BACK-END y FRONT-END</a>.
        </div>
        <div class="alert alert-info">
            <strong>¡Info!</strong> Si deseas ver el archivo <a href="https://my-json-server.typicode.com/Hyperyor/datosjson/db" class="alert-link"> JSON EXTERNO</a>.
        </div>
      </div>
  </div>

  <!-- Page Content -->
  <div class="container">
    <section>
      <h2 class="text-center">Listado de Frameworks</h2><br><br>
        
            <div class="table-responsive">
                <table class="table table-hover table-striped table-dark">
                    <thead>
                        <tr>
                        <th scope="col"> NOMBRE</th>
                        <th scope="col">TIPO</th>
                        <th scope="col">LANZAMIENTO</th>
                        <th scope="col">COMPATIBILIDAD</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="obj in listaJson">
                            <th scope="row" class="text-warning">{{obj.nombre}}</th>
                            <td>{{obj.tipo}}</td>
                            <td>{{obj.lanzamiento}}</td>
                            <td >
                                <ul ng-repeat="ele in obj.compatibilidad">
                                    <li class="text-success">{{ele}}</li>
                                </ul>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
    </section>
  </div>


    <!-- Footer -->
    <footer class="py-5 bg-dark">
        <div class="footer">
        <p class="m-0 text-center text-white">Sergio Ruiz Romero 2ºDAM 2020</p>
        </div>
    </footer>
</body>

</html>
