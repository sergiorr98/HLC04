<?php

$parametro= $_GET["valor"];

$variable = (string)$parametro;
$server = "mysql";
$user = "usuario";
$pass = "1234";
$bd = "db";

//Creamos la conexión
$conexion = mysqli_connect($server, $user, $pass,$bd) 
or die("Ha sucedido un error inexperado en la conexion de la base de datos");

if (strcmp($variable, '111A')===0)
{
	//generamos la consulta
	$sql = "SELECT * FROM PARTIDO WHERE CODIGO_ARBITRO='111A'";
	mysqli_set_charset($conexion, "utf8"); //formato de datos utf8

	if(!$result = mysqli_query($conexion, $sql)) die();

	$clientes = array(); //creamos un array

	while($row = mysqli_fetch_array($result)) 
	{ 
		$id=$row['CODIGO'];
		$id2=$row['ESTADIO'];
		$id3=$row['CAPACIDAD'];
		$id4=$row['CODIGO_ARBITRO'];

		

		$clientes[] = array('CODIGO'=>$id, 'ESTADIO'=> $id2, 'CAPACIDAD'=>$id3, 'CODIGO_ARBITRO'=>$id4);

	}
		
	//desconectamos la base de datos
	$close = mysqli_close($conexion) 
	or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
	  
	$variable='';
	//Creamos el JSON
	//$clientes['clientes'] = $clientes;
	$json_string = json_encode($clientes);
	echo $json_string;
	//Si queremos crear un archivo json, sería de esta forma:
	/*
	$file = 'clientes.json';
	file_put_contents($file, $json_string);
	*/
}
if (strcmp($variable, '222A')===0)
{
	//generamos la consulta
	$sql = "SELECT * FROM PARTIDO WHERE CODIGO_ARBITRO='222A'";
	mysqli_set_charset($conexion, "utf8"); //formato de datos utf8

	if(!$result = mysqli_query($conexion, $sql)) die();

	$clientes = array(); //creamos un array

	while($row = mysqli_fetch_array($result)) 
	{ 
		$id=$row['CODIGO'];
		$id2=$row['ESTADIO'];
		$id3=$row['CAPACIDAD'];
		$id4=$row['CODIGO_ARBITRO'];

		$clientes[] = array('CODIGO'=>$id, 'ESTADIO'=> $id2, 'CAPACIDAD'=>$id3, 'CODIGO_ARBITRO'=>$id4);

	}
		
	//desconectamos la base de datos
	$close = mysqli_close($conexion) 
	or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
	  

	//Creamos el JSON
	//$clientes['clientes'] = $clientes;
	$json_string = json_encode($clientes);
	echo $json_string;
}

if (strcmp($variable, '333C')===0)
{
	//generamos la consulta
	$sql = "SELECT * FROM PARTIDO WHERE CODIGO_ARBITRO='333C'";
	mysqli_set_charset($conexion, "utf8"); //formato de datos utf8

	if(!$result = mysqli_query($conexion, $sql)) die();

	$clientes = array(); //creamos un array

	while($row = mysqli_fetch_array($result)) 
	{ 
		$id=$row['CODIGO'];
		$id2=$row['ESTADIO'];
		$id3=$row['CAPACIDAD'];
		$id4=$row['CODIGO_ARBITRO'];

		$clientes[] = array('CODIGO'=>$id, 'ESTADIO'=> $id2, 'CAPACIDAD'=>$id3, 'CODIGO_ARBITRO'=>$id4);
	}
		
	//desconectamos la base de datos
	$close = mysqli_close($conexion) 
	or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
	  

	//Creamos el JSON
	//$clientes['clientes'] = $clientes;
	$json_string = json_encode($clientes);
	echo $json_string;
}





?>