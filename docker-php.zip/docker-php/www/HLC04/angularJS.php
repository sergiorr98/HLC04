<!DOCTYPE html>
<html lang="en" ng-app="ToDoList">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>PRACTICA HLC04 - SERGIO RUIZ</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.9/angular.min.js"></script>
  <script src="vendor/AngularJS/angular-local-storage.min.js"></script>
  <script src="vendor/AngularJS/controller.js"></script>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

<!-- Esto se hace para que se tenga ese tipo de letra en el documento
      No se puede aplicar en el boostrap ya que no surge efecto
-->
  <style>
    body
    {
      font-family: 'Poppins', sans-serif;
    }
  </style>

</head>

<body ng-controller="ToDoController">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top sticky-top">
    <div class="container">
      <a class="navbar-brand" href="inicio.php">INICIO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="boostrap.php">BOOSTRAP
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="jquery.php">JQUERY</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_local.php">JSON LOCAL</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="json_externo.php">JSON EXTERNO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="angularJS.php">ANGULAR JS</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
    <div class="row">
      </br></br><img src="img/AngularJS_logo.svg.png" class="mx-auto d-block" alt="imagenGlobal" width="800" height="250">
      
      <article class="container p-3 my-3 bg-primary text-white">
        <div class="spinner-grow text-light"></div>
        <h2 class = "text-center">¿QUÉ ES ANGULAR JS?</h2></br>
        <p class="lead"> AngularJS es Javascript. Es un proyecto de código abierto, realizado en Javascript que contiene un conjunto de librerías útiles para el desarrollo de aplicaciones web y propone una serie de patrones de diseño para llevarlas a cabo. En pocas palabras, es lo que se conoce como un framework para el desarrollo, en esta caso sobre el lenguaje Javascript con programación del lado del cliente.
        Puedes encontrar el proyecto de AngularJS en su propio sitio web: AngularJS, Superheroic JavaScript MVW Framework. Al ser un proyecto de código abierto cualquier persona con un poco de curiosidad echar un vistazo con profundidad y ver cómo se ha escrito, incluso admiten colaboraciones de desarrolladores que quiera aportar cosas. </p>
      </article>

      <article class="container p-3 my-3 bg-danger text-white">
        <div class="spinner-grow text-light"></div>
        <h2 class = "text-center" >MEJORAS DEL HTML</h2></br>
        <p class="lead">  Este Javascript pretende que los programadores mejoren el HTML que hacen. Que puedan producir un HTML que, de manera declarativa, genere aplicaciones que sean fáciles de entender incluso para alguien que no tiene conocimientos profundos de informática. El objetivo es producir un HTML altamente semántico, es decir, que cuando lo leas entiendas de manera clara qué es lo que hace o para qué sirve cada cosa.

        Lógicamente, AngularJS viene cargado con todas las herramientas que los creadores ofrecen para que los desarrolladores sean capaces de crear ese HTML enriquecido. La palabra clave que permite ese HTML declarativo en AngularJS es "directiva", que no es otra cosa que código Javascript que mejora el HTML. Puedes usar el que viene con AngularJS y el que han hecho terceros desarrolladores, puesto que muchas personas están contribuyendo con pequeños proyectos -independientes del propio framework- para enriquecer el panorama de directivas disponibles. Hasta este punto serás un "consumidor de directivas", y finalmente cuando vayas tomando experiencia serás capaz de convertirte en un "productor de directivas", enriqueciendo tú mismo las herramientas para mejorar tu propio HTML. </p>
        
      </article>

      <article class="container p-3 my-3 bg-warning text-white">
        <div class="spinner-grow text-light"></div>
        <h2 class = "text-center">ANGULAR JS A VISTA DE PÁJARO</h2></br>
        <p class="lead">Ahora vamos a hacer un breve recorrido para nombrar y describir con unos pequeños apuntes aquellos elementos y conceptos que te vas a encontrar dentro de AngularJS.</p>
        <table class="table table-dark table-hover">
        <tbody>
          <tr>
            <td class="text-warning">VISTAS</td>
            <td>Será el HTML y todo lo que represente datos o información.</td>
          </tr>
          <tr>
            <td class="text-warning">CONTROLADORES</td>
            <td>Se encargarán de la lógica de la aplicación y sobre todo de las llamadas "Factorías" y "Servicios" para mover datos contra servidores o memoria local en HTML5.</td>
          </tr>
          <tr>
            <td class="text-warning">MODELO DE LA VISTA</td>
            <td>En Angular el "Modelo" es algo más de aquello que se entiende habitualmente cuando te hablan del MVC tradicional, osea, las vistas son algo más que el modelo de datos. En modo de ejemplo, en aplicaciones de negocio donde tienes que manejar la contabilidad de una empresa, el modelo serían los movimientos contables. Pero en una pantalla concreta de tu aplicación es posible que tengas que ver otras cosas, además del movimiento contable, como el nombre de los usuarios, los permisos que tienen, si pueden ver los datos, editarlos, etc. Toda esa información, que es útil para el programador pero que no forma parte del modelo del negocio, es a lo que llamamos el "Scope" que es el modelo en Angular.</td>
          </tr>
          <tr>
            <td class="text-warning">MÓDULOS</td>
            <td>La manera que nos va a proponer AngularJS para que nosotros como desarrolladores seamos cada vez más ordenados, que no tengamos excusas para no hacer un buen código, para evitar el código espaguetti, ficheros gigantescos con miles de líneas de código, etc. Podemos dividir las cosas, evitar el infierno de las variables globales en Javascript, etc. Con los módulos podemos realizar aplicaciones bien hechas, de las que un programador pueda sentirse orgulloso y sobre todo, que nos facilite su desarrollo y el mantenimiento. </td>
          </tr>
        </tbody>
      </table>
      </article>

      <article class="container p-3 my-3 bg-dark text-white">
        <div class="container">
          <h2>Tu opinión nos interesa</h2>
          <p>Si te gustaría comentar algo para mejorar nuestra página este es el momento</p>
            <div class="alert alert-warning">
              <strong>¡Atención!</strong> Revisa las <a href="https://blog.realinstitutoelcano.org/blog-elcano/normas-comunidad/" class="alert-link">normas de la comunidad</a> antes de comentar.
            </div>
            <div class="form-group">
              <form ng-submit="addActv()">
                <label for="usr">Nombre:</label>
                <input type="text" class="form-control" id="usr" name="username" ng-model="newActv.nombre">
              </div>
              <div class="form-group">
                <label for="pwd">Comentario:</label>
                <input type="text" class="form-control" id="pwd" name="password" ng-model="newActv.descripcion">
              </div>
              <input type="submit" value="Enviar comentario">
            </form>

      </div>
      </article>

      <article class="container p-3 my-3 bg-dark text-white">
        <h3>Comentarios</h3>
        <ul>
          <li ng-repeat="actividad in todo">
           {{actividad.nombre}} - <strong>{{actividad.descripcion}}</strong>   
          </li>
          <form ng-submit="clean()">
              <br><input type="submit" value="Limpiar comentarios">
          </form>
       </ul>
      </article>

    </div>
  </div>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/bootstrap/css/boostrap.min.css"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Footer -->
    <footer class="py-5 bg-dark">
        <div class="footer">
        <p class="m-0 text-center text-white">Sergio Ruiz Romero 2ºDAM 2020</p>
        </div>
    </footer>

</body>

</html>
